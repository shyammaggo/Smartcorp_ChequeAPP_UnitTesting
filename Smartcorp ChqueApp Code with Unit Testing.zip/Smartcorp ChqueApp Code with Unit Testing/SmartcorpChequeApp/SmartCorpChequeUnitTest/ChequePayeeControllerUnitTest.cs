using Contracts;
using Entities.Models;
using LoggerService;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SmartcorpChequeapp.Controllers;
using System;
using System.Collections.Generic;

namespace SmartCorpChequeUnitTest
{
    [TestClass]
    public class ChequePayeeControllerUnitTest
    {
        //Arrange
        ChequePayee cp1;
        ChequePayee cp2;
        ChequePayee cp3;

        private LoggerManager _logger;
        private Mock<IRepositoryWrapper> _repository;
        private List<ChequePayee> ChequePayeeList;

        ChequePayeeController ctrl;
        public ChequePayeeControllerUnitTest()
        {
            cp1 = new ChequePayee { Id = 1, PayeeName = "Robert", ChequeAmount = 100, ChequeDate = DateTime.Now.AddDays(7) };
            cp2 = new ChequePayee { Id = 2, PayeeName = "Mike", ChequeAmount = 200, ChequeDate = DateTime.Now.AddDays(9) };
            cp3 = new ChequePayee { Id = 3, PayeeName = "Frank", ChequeAmount = 300, ChequeDate = DateTime.Now.AddDays(11) };

            ChequePayeeList = new List<ChequePayee>();
            ChequePayeeList.Add(cp1);
            ChequePayeeList.Add(cp2);

            _logger = new LoggerManager();
            _repository = new Mock<IRepositoryWrapper>();

            ctrl = new ChequePayeeController(_logger, _repository.Object);
        }

        [TestMethod]
        public void TestGetAllChequePayeesOK()
        {
            //mocking
            _repository.Setup(r => r.chequePayee.GetAllChequePayees()).Returns(ChequePayeeList);

            //Action
            var response = ctrl.GetAllChequePayees() as ObjectResult;
            List<ChequePayee> data = response.Value as List<ChequePayee>;

            //Assert
            Assert.AreEqual(200, response.StatusCode);
            CollectionAssert.Contains(data, cp1);
            CollectionAssert.Contains(data, cp1);
        }

        [TestMethod]
        public void TestGetAllChequePayeesInternalServerError()
        {
            //didn't setup mocking to raise error

            //Action
            var response = ctrl.GetAllChequePayees() as ObjectResult;

            //Assert
            Assert.AreEqual(500, response.StatusCode);
        }

        [TestMethod]
        public void TestCreateChequePayeeCreated()
        {
            ChequePayeeDTO payee= new ChequePayeeDTO
            {
                PayeeName = cp3.PayeeName,
                ChequeAmount = cp3.ChequeAmount,
                ChequeDate = cp3.ChequeDate.ToString(),
                Id = cp3.Id
            };

            //mocking
            _repository.Setup(r => r.chequePayee.CreateChequePayee(cp3)).Callback((ChequePayee model) =>
            {
                ChequePayeeList.Add(model);
            });

            //Action
            var response = ctrl.CreateChequePayee(payee) as ObjectResult;
            
            //Assert
            Assert.AreEqual(201, response.StatusCode);
        }

        [TestMethod]
        public void TestCreateChequePayeeBadRequest()
        {
            //Action
            var response = ctrl.CreateChequePayee(null) as ObjectResult;

            //Assert
            Assert.AreEqual(400, response.StatusCode);
        }

        [TestMethod]
        public void TestCreateChequePayeeInternalServerError()
        {
            ChequePayeeDTO payee = new ChequePayeeDTO
            {
                PayeeName = cp3.PayeeName,
                ChequeAmount = cp3.ChequeAmount,
                ChequeDate = cp3.ChequeDate.ToString(),
                Id = cp3.Id
            };

            //didn't setup mocking to raise error

            //Action
            var response = ctrl.CreateChequePayee(payee) as ObjectResult;

            //Assert
            Assert.AreEqual(500, response.StatusCode);
        }
    }
}
