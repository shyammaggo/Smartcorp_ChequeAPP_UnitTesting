﻿using Contracts;
using Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repository
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private RepositoryContext _repoContext;
        private IChequePayee _chequepayee;
        public RepositoryWrapper(RepositoryContext repoContext)
        {
            _repoContext = repoContext;
        }

        public IChequePayee chequePayee
        {
            get
            {
                if(_chequepayee == null)
                {
                    _chequepayee = new ChequePayeeRepository(_repoContext);
                }
                return _chequepayee;
            }
        }

        

        public void Save()
        {
            _repoContext.SaveChanges();
        }
    }
}
