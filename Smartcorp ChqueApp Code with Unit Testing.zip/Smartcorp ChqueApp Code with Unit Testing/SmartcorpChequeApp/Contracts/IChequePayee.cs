﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts
{
   public interface IChequePayee :IRepositoryBase<ChequePayee>
    {
        IEnumerable<ChequePayee> GetAllChequePayees();
        void CreateChequePayee(ChequePayee chequeP);
    }
}
