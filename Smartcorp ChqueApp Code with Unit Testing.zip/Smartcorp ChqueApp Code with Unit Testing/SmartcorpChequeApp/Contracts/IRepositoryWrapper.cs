﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts
{
    public interface IRepositoryWrapper
    {
        IChequePayee chequePayee { get; }
        void Save();
    }
}
