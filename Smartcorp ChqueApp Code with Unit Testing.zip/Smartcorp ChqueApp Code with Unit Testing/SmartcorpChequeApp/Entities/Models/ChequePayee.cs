﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
//DESKTOP-I4G4MAV\SATSAHIB2019  SmartcorpChequeApp
namespace Entities.Models
{
    [Table("ChequePayee")]
    public class ChequePayee
    {
         [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

         [Required(ErrorMessage = "Payee name is required.")]
         [StringLength(60, ErrorMessage = "Please enter Payee name.")]
         public string PayeeName { get; set; }

         [Required(ErrorMessage = "Please enter cheque date.")]
         public DateTime ChequeDate { get; set; }

         [Required(ErrorMessage = "Please enter cheque amount")]
         [StringLength(100, ErrorMessage = "Enter cheque amount")]
        public decimal ChequeAmount { get; set; }
    }
}
