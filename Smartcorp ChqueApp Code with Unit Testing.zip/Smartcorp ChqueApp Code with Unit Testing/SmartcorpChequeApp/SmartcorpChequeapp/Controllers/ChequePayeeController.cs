﻿using System;
using Contracts;
using Entities.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SmartcorpChequeapp.Controllers
{
    public class ChequePayeeDTO
    {

        public int Id { get; set; }

        public string PayeeName { get; set; }

        public string ChequeDate { get; set; }

        public decimal ChequeAmount { get; set; }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class ChequePayeeController : Controller
    {

        private ILoggerManager _logger;
        private IRepositoryWrapper _repository;

        public ChequePayeeController(ILoggerManager logger, IRepositoryWrapper repository)
        {
            _logger = logger;
            _repository = repository;
        }

        [HttpGet("[action]")]
        public IActionResult GetAllChequePayees()
        {
            try
            {
                var chequepayees = _repository.chequePayee.GetAllChequePayees();

                _logger.LogInfo($"Returned all chequepayees from database.");

                return Ok(chequepayees);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside GetAllChequePayees action: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost("[action]")]
        public IActionResult CreateChequePayee([FromBody]ChequePayeeDTO chequeP)
        {
            try
            {
                if (chequeP == null)
                {
                    _logger.LogError("chequeP object sent from client is null.");
                    return BadRequest("chequeP object is null");
                }

                ChequePayee payee = new ChequePayee();

                payee.PayeeName = chequeP.PayeeName;
                payee.ChequeAmount = chequeP.ChequeAmount;
                payee.ChequeDate = Convert.ToDateTime(chequeP.ChequeDate);

                _repository.chequePayee.CreateChequePayee(payee);
                _repository.Save();

                return StatusCode(201, "Created");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside CreateChequePayee action: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
