export interface ChequePayee {
    id: number;
    payeeName: string;
    chequeAmount: number;
    chequeDate: string;
}
