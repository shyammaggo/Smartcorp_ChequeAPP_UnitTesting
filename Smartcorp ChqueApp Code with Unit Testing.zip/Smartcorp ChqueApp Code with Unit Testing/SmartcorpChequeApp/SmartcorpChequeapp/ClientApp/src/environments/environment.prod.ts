export const environment = {
  production: true,
  apiAddress: 'https://localhost:44387/api'
};
