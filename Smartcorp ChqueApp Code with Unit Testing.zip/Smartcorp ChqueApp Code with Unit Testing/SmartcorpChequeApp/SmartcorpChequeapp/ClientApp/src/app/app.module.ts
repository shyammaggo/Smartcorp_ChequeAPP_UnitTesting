import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { FieldErrorDisplayComponentComponent } from './field-error-display-component/field-error-display-component.component';
import { NumberToWordsPipePipe } from './number-to-words-pipe.pipe';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { ViewchequeComponent } from './viewcheque/viewcheque.component';
import { PayeeService } from './services/payee.service';

@NgModule({
  declarations: [
    AppComponent,
    FieldErrorDisplayComponentComponent,
    NumberToWordsPipePipe,
    NavMenuComponent,
    HomeComponent,
    FetchDataComponent,
    ViewchequeComponent

  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'viewcheque/:payeeName/:amountDollar/:chequeDate', component: ViewchequeComponent },
      { path: 'fetch-data', component: FetchDataComponent },
    ])
  ],
  providers: [PayeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
