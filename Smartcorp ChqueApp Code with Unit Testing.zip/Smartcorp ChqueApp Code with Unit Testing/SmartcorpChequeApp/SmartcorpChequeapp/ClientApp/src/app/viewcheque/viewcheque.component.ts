import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-viewcheque',
  templateUrl: './viewcheque.component.html'
})
export class ViewchequeComponent implements OnInit, OnDestroy {
  payeeName: any;
  ChequeAmount: any;
  chequeDate: any;
  private sub: any;

  constructor(private route: ActivatedRoute) {

  }
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.payeeName = params['payeeName'];
      this.ChequeAmount = params['ChequeAmount'];
      this.chequeDate = params['chequeDate'];
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
