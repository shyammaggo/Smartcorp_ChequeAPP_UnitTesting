import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ViewchequeComponent } from './viewcheque.component';
import { NumberToWordsPipePipe } from '../number-to-words-pipe.pipe';
import { ActivatedRoute } from '@angular/router';

describe('ViewchequeComponent', () => {
  let component: ViewchequeComponent;
  let fixture: ComponentFixture<ViewchequeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewchequeComponent, NumberToWordsPipePipe],
      providers: [{ provide: ActivatedRoute }]
    });

    fixture = TestBed.createComponent(ViewchequeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
