import { NumberToWordsPipePipe } from './number-to-words-pipe.pipe';

describe('NumberToWordsPipePipe', () => {
  it('create an instance', () => {
    const pipe = new NumberToWordsPipePipe();
    expect(pipe).toBeTruthy();
  });
});
