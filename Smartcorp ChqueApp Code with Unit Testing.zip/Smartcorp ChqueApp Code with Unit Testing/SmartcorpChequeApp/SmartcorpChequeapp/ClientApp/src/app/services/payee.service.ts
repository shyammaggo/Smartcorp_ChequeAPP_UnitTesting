import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ChequePayee } from 'src/models/chequePayee';

@Injectable()
export class PayeeService {
    headers: HttpHeaders;
    constructor(private http: HttpClient) {
        this.headers = new HttpHeaders({ 'content-type': 'application/json' });
    }
    GetChequePayees(): Observable<ChequePayee[]> {
        return this.http.get<ChequePayee[]>(environment.apiAddress + '/ChequePayee/GetAllChequePayees');
    }
    AddChequePayee(model: ChequePayee): Observable<HttpResponse<any>> {
        return this.http.post<HttpResponse<any>>(environment.apiAddress + '/ChequePayee/CreateChequePayee',
            JSON.stringify(model), { headers: this.headers, observe: 'response' });
    }
}
