import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { dateValidator } from '../dateValidator';
import { Router } from "@angular/router";
import { PayeeService } from '../services/payee.service';
import { ChequePayee } from 'src/models/chequePayee';

const DATE_REGEX = new RegExp(/^(\d{2}|\d)\/(\d{2}|\d)\/\d{4}$/);

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {
  constructor(private formBuilder: FormBuilder, private route: Router, private payeeService: PayeeService) { }
  Cheque: ChequePayee;
  registerForm: FormGroup;
  submitted = false;
  title = 'chequeapplication';
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      payeeName: ['', Validators.required],
      chequeAmount: ['', [Validators.required, Validators.min(0), Validators.max(10000000000000)]],
      chequeDate: ['', [Validators.required, Validators.maxLength(10), Validators.pattern(DATE_REGEX),
      dateValidator()]],

    });
  }

  isFieldValid(field: string) {
    if (this.submitted) {
      return !this.registerForm.get(field).valid;
    }
    return !this.registerForm.get(field).valid && this.registerForm.get(field).touched;
  }
  onSubmit() {
    this.submitted = true;
    if (this.registerForm.valid) {
      this.Cheque = this.registerForm.value;

      this.payeeService.AddChequePayee(this.Cheque).subscribe((res) => {
        if (res.status == 201) {
          this.route.navigate(['/viewcheque', this.Cheque.payeeName, this.Cheque.chequeAmount, this.Cheque.chequeDate]);
        }
      }, (err) => {
        if (err.status == 201) {
          this.route.navigate(['/viewcheque', this.Cheque.payeeName, this.Cheque.chequeAmount, this.Cheque.chequeDate]);
        }
      });
    }
  }
}
