import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { HomeComponent } from './home.component';
import { FieldErrorDisplayComponentComponent } from '../field-error-display-component/field-error-display-component.component';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { PayeeService } from '../services/payee.service';

describe('homeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule],
      declarations: [HomeComponent, FieldErrorDisplayComponentComponent],
      providers: [PayeeService, { provide: Router }]
    });

    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create a form with three controls', () => {
    expect(component.registerForm.contains('payeeName')).toBeTruthy();
    expect(component.registerForm.contains('chequeAmount')).toBeTruthy();
    expect(component.registerForm.contains('chequeDate')).toBeTruthy();
  });

  it('should make the name control required', () => {
    let control = component.registerForm.get('payeeName');
    control.setValue('');
    expect(control.valid).toBeFalsy();
  });

  it('should check for min and max range value', () => {
    let control = component.registerForm.get('chequeAmount');
    control.setValue(-1);
    expect(control.valid).toBeFalsy();
  });

  it('should return form validity false when clicking submit button without passing values', () => {
    let submitEl = fixture.debugElement.query(By.css('.btn-primary'));
    submitEl.nativeElement.click(); // for submit button
    expect(component.registerForm.valid).toBe(false);
  });

  it('should call onSubmit() method', () => {
    let submitEl = fixture.debugElement.query(By.css('.btn-primary'));
    spyOn(component, 'onSubmit');
    submitEl.nativeElement.click();
    //fixture.detectChanges();
    expect(component.onSubmit).toHaveBeenCalled();
  });
});
