import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchDataComponent } from './fetch-data.component';
import { PayeeService } from '../services/payee.service';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';

describe('FetchDataComponent', () => {
  let component: FetchDataComponent;
  let fixture: ComponentFixture<FetchDataComponent>;
  let payeeService: PayeeService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FetchDataComponent],
      imports: [HttpClientModule],
      providers: [PayeeService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FetchDataComponent);
    component = fixture.componentInstance;
    payeeService = TestBed.get(PayeeService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should load all cheque payees', () => {
    const mockPayees = [
      {
        'id': 101,
        'payeeName': 'Adam',
        'chequeAmount': 100,
        'chequeDate': '10/02/2019'
      },
      {
        'id': 102,
        'payeeName': 'Mike',
        'chequeAmount': 101,
        'chequeDate': '10/15/2019'
      }
    ];

    spyOn(payeeService, 'GetChequePayees').and.returnValues(of(mockPayees));
    component.ngOnInit();
    expect(component.chequePayees).toEqual(mockPayees);
  });
});
