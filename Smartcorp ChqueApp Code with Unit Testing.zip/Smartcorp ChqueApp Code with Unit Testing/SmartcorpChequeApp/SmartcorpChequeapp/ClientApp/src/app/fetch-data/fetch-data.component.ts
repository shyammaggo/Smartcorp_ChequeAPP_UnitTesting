import { Component, Inject, OnInit } from '@angular/core';
import { PayeeService } from '../services/payee.service';
import { ChequePayee } from 'src/models/chequePayee';

@Component({
    selector: 'app-fetch-data',
    templateUrl: './fetch-data.component.html'
})
export class FetchDataComponent implements OnInit {
    public chequePayees: ChequePayee[];

    constructor(private payeeService: PayeeService) {

    }

    ngOnInit() {
        this.payeeService.GetChequePayees().subscribe(result => {
            this.chequePayees = result;
        }, error => console.error(error));
    }
}
